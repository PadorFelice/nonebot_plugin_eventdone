# Nonebot_plugin_eventdone
远程好友申请事件的处理~这是我第一次写插件喵~请多多指教，有问题请尽快联系我喵~


使用说明
1.直接下载压缩包/使用git clone  gh repo clone PadorFelice/Nonebot_plugin_eventdone
2.解压放入你的plugin文件夹即可食用喵~（记得查看PS！！！）

PS：罐头是我家猫猫的名字，您当然也可以改成您喜欢的东西的名字
    在运行前请先检查import的组件您是否已经准备齐全，超级用户是否在.env中设置完毕
    本组件基于nonebot运行，如果您使用的不是nonebot，出错概不负责
    
有疑问（请事先查看提问的智慧）   
    自己想
    issue
